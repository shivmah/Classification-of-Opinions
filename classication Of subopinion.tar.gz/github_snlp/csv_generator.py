from wordsegment import segment
import re
import CMUTweetTagger
import arff
from nltk.stem import PorterStemmer
from nltk.parse.stanford import StanfordDependencyParser
from collections import Counter
from nltk.tag.stanford import StanfordPOSTagger
import csv
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
import os
print "sub-opinion classification "
print " 1: youtube comments "
print " 2: hashtags"
print " 3: newspaper articles"

k=int(raw_input("Enter type of data set :"))

if(k==1):
	folder_name="./youtube"
	f=open(folder_name+"/youtube_dataset_Sheet1.csv",'r')
	
	f_output=open("./result/youtube_sub_opinion_result.csv","w")	
	f_output.write("hashtag,verb present,adj present,strong_adjective,weak_adjective,no_of_pronouns,no_of_adverbs,acomp,advcl,amod,ccomp,xcomp,nummod,dep,dobj,iobj,report_words,judgement_words,advise_words,sentiment_words,no_of_nouns,named_entity_present,num_of_agent,num_of_appos,num_of_aux,num_of_auxpass,num_of_cc,num_of_conj,num_of_cop,num_of_csubj,num_of_csubjpass,num_of_det,num_of_discourse,num_of_expl,num_of_goes_with,num_of_mark,num_of_mwe,num_of_neg,num_of_nn,num_of_npadvmod,num_of_nsubj,num_of_nsubjpass,num_of_num,num_of_number,num_of_parataxis,num_of_pcomp,num_of_pobj,num_of_poss,num_of_possessive,num_of_preconj,num_of_predet,num_of_prep,num_of_prepc,num_of_prt,num_of_punct,num_of_quantmod,num_of_rcmod,num_of_ref,num_of_root,num_of_tmod,num_of_vmod,num_of_xcomp,num_of_xsubj,fo\n")

	hashtags=[]
	hashtags_segmented=[]

	file_of_strong_adj=open("strong.txt")
	list_of_strong_adj_words=file_of_strong_adj.readlines()
	for i in range(len(list_of_strong_adj_words)):
		list_of_strong_adj_words[i]=list_of_strong_adj_words[i].strip("\r\n")



	file_of_weak_adj=open("weak.txt")
	list_of_weak_adj_words=file_of_weak_adj.readlines()
	for i in range(len(list_of_weak_adj_words)):
		list_of_weak_adj_words[i]=list_of_weak_adj_words[i].strip("\r\n")



	file_of_stop_words=open("stop_words.txt")
	list_of_stop_words=file_of_stop_words.readlines()
	for i in range(len(list_of_stop_words)):
		list_of_stop_words[i]=list_of_stop_words[i].strip("\r\n")


	file_of_opi_words=open("opi_words.txt")
	list_of_opi_lines=file_of_opi_words.readlines()
	for i in range(len(list_of_opi_lines)):
		list_of_opi_lines[i]=list_of_opi_lines[i].strip("\r\n")


	list_of_opi_words=[]
	for line in list_of_opi_lines:
		l=line.split()
		list_of_opi_words.append(l) 
	
	
	
	original_hashtags=[]
	no_of_words=[]

	
	f_lines=csv.reader(f) 

	fo=[]
	char_count=[]

	for hashtag in f_lines:
	
		f_o=hashtag[2]
		hashtag=hashtag[0]
	
		original_hashtags.append(hashtag)
		#print original_hashtags 
	
	    	re.sub('^[0-9 ]*','',hashtag)
	    	#char_count.append(len(hashtag))
		#print len(hashtag)

	    	hashtags_segmented.append(hashtag.split())
	    	#no_of_words.append(len(hashtag))
	  	hash_string = hashtag
	    	hashtags.append(hash_string)
		fo.append(f_o)
	

	postagged_hashtags=[] 
	print "1"
	st=StanfordPOSTagger('./stanford-postagger/models/english-bidirectional-distsim.tagger','./stanford-postagger/stanford-postagger.jar')
	   
	for line in hashtags:
		postagged_hashtags.append(st.tag([line]))

	#print postagged_hashtags
	print "2"

	#newline = [str.split(',')[0] for str in lines]
	vCol = []
	aCol = []
	sVCol = []
	whCol = []
	opCol = []
	fact_col = []
	no_of_strong_adj=[]
	no_of_weak_adj=[]
	num_words=[]
	no_of_pronoun = []
	num_of_adverbs=[]

	num_of_acomp=[]
	num_of_ccomp=[]
	num_of_amod=[]
	num_of_advcl=[]
	num_of_advmod=[]
	num_of_xcomp=[]
	num_of_nummod=[]
	num_of_dep=[]
	num_of_dobj=[]
	num_of_iobj=[]
	num_of_agent=[]
	num_of_cop=[]
	num_of_appos=[]
	num_of_aux=[]
	num_of_auxpass=[]
	num_of_cc=[]
	num_of_ccomp=[]
	num_of_conj=[]
	num_of_csubj=[]
	num_of_csubjpass=[]
	num_of_dep=[]
	num_of_det=[]
	num_of_discourse=[]
	num_of_expl=[]
	num_of_goes_with=[]
	num_of_mark=[]
	num_of_mwe=[]
	num_of_neg=[]
	num_of_nn=[]
	num_of_npadvmod=[]
	num_of_nsubj=[]
	num_of_nsubjpass=[]
	num_of_number=[]
	num_of_num=[]
	num_of_parataxis=[]
	num_of_pcomp=[]
	num_of_pobj=[]
	num_of_poss=[]
	num_of_possessive=[]
	num_of_preconj=[]
	num_of_preconj=[]
	num_of_predet=[]
	num_of_prep=[]
	num_of_prepc=[]
	num_of_prt=[]
	num_of_punct=[]
	num_of_quantmod=[]
	num_of_rcmod=[]
	num_of_ref=[]
	num_of_root=[]
	num_of_tmod=[]
	num_of_vmod=[]
	num_of_xcomp=[]
	num_of_xsubj=[]


	report_words=[]
	judgement_words=[]
	advise_words=[]
	sentiment_words=[]
	named_entity_present=[]
	no_of_nouns=[]
	presence_of_year=[] 
	end_with_day =[]
	start_with_the = []
	named_entity_present=[]
	no_of_nouns=[]
	report_words=[]
	
	print "3"
	hashtags_segmented_without_stop_words=[]
	for tag in hashtags_segmented:
		count_of_strong_adj=0
		count_of_weak_adj=0
		num_words.append(len(tag))
		for word in tag:
			if word in list_of_strong_adj_words:
				count_of_strong_adj += 1

			if word in list_of_weak_adj_words:
				count_of_weak_adj += 1

			if word not in list_of_stop_words:
				hashtags_segmented_without_stop_words.append(word)
	
		no_of_strong_adj.append(count_of_strong_adj)		
		no_of_weak_adj.append(count_of_weak_adj)
	print "4"
	ps=PorterStemmer()

	hashtags_stemmed=[]
	for line in postagged_hashtags:
		pronoun_num=noun_num=0
		v=a=sv=ne=y=0
		svt=evd=0
		num_adverbs=0
		stemmed = []
		for tuple_t in line:
			sentence = tuple_t[1]
			if sentence in ['VB','VBN','VBD','VBG','VBP','VBZ'] :
				v += 1
	
			if  sentence in ['JJ','JJR','JJS']:
				a += 1
			if sentence in ['RB','RBR','RBS','WRB']	:
				num_adverbs += 1
			#if 'V' == line[0][1]:
			#	sv=1
		
			if sentence in ['NN','NNS','NNP','NNPS']:
				noun_num += 1
			
			if sentence in ['PRP','PRP$']:
				pronoun_num +=1

			if sentence in ['NNP','NNPS']:
				ne += 1
			#if sentence in ['N', 'S', 'L']:
			#	noun_num += 1
		
			if sentence in ['NN','NNS','NNP','NNPS','PR','PRP$','WP','WP$']:
				stemmed.append(tuple_t[0])
			else:
				stemmed.append(ps.stem(tuple_t[0]))
	

		
		
		vCol.append(v)
		aCol.append(a)
		num_of_adverbs.append(num_adverbs)
		named_entity_present.append(ne)
		no_of_pronoun.append(pronoun_num)
		no_of_nouns.append(noun_num)
		hashtags_stemmed.append(stemmed)
		#presence_of_year.append(y)
		#end_with_day.append(evd)
		#start_with_the.append(svt)		


	print "5"
	for line in hashtags_stemmed:
		match_list=[]
		#op = 0
		num_report=num_advise=num_judgement=num_sentiment=0
		for word in line:
			for lis in list_of_opi_words:
				if word in lis:
					match_list.append(lis[0])
					#op = 1
		for num_out in match_list:
			if num_out=='1':
			    num_report=1
			if num_out=='2':
			    num_judgement=1
			if num_out=='3':
			    num_advise=1
			if num_out=='4':
			    num_sentiment=1
		#opCol.append(op)
		report_words.append(num_report)
		judgement_words.append(num_judgement)
		advise_words.append(num_advise)
		sentiment_words.append(num_sentiment)
	
	

	dep_parser=StanfordDependencyParser('stanford-parser/stanford-parser.jar','stanford-parser/stanford-parser-3.6.0-models.jar')
	print "7"
	for line in hashtags :
		print line
		result=dep_parser.raw_parse(line)
		dep=result.next()
		k_tri=list(dep.triples())
		#print k_tri
		count_total=Counter(tags for word1,tags,word2 in k_tri)
		num_acomp=num_ccomp=num_amod=num_advcl=num_advmod=num_xcomp=num_nummod=num_dep=num_dobj=num_iobj=num_agent=num_appos=num_aux=num_auxpass=num_cc=num_ccomp=num_conj=num_cop=num_csubj=num_csubjpass=num_dep=num_det=num_discourse=num_dobj=num_expl=num_goes_with=num_iobj=num_mark=num_mwe=num_neg=num_nn=num_npadvmod=num_nsubj=num_nsubjpass=num_num=num_number=num_parataxis=num_pcomp=num_pobj=num_poss=num_possessive=num_preconj=num_predat=num_predet=num_prep=num_prepc=num_prt=num_punct=num_quantmod=num_rcmod=num_ref=num_root=num_tmod=num_vmod=num_xcomp=num_xsubj=0
	
		match_found=None               
		for w1,tag,w2 in k_tri:
			if tag=='dobj':
		    		num_dobj=1
		    		#print w1[0]
		    		if w1[1] in ['VB','VBN','VBD','VBG','VBP','VBZ'] :
		    			for i in range(len(list_of_opi_words)):
		    				for k in range(len(list_of_opi_words[i])):
		    					if k!=0 and k!=1:
		    						if list_of_opi_words[i][k]==ps.stem(w1[0]) and match_found!=list_of_opi_words[i][k]:
		    							num_dobj=num_dobj+1
			                        			match_found=list_of_opi_words[i][k]
			                        			#print 'match for dobj'
	
				   
			if tag=='iobj':
			    #print w1[0]
			    num_iobj=1
			    if w1[1]in ['VB','VBN','VBD','VBG','VBP','VBZ'] :
				for i in range(len(list_of_opi_words)):
		    				for k in range(len(list_of_opi_words[i])):
		    					if k!=0 and k!=1:
		    						if list_of_opi_words[i][k]==ps.stem(w1[0]) and match_found!=list_of_opi_words[i][k]:
		    							num_iobj=num_iobj+1
			                        			match_found=list_of_opi_words[i][k]
			                        			#print 'match for iobj' 
					    
					
			if tag=='dep':
			    num_dep=num_dep+1
			    #print w1[0]
			    #print w2[0]
			    for i in range(len(list_of_opi_words)):#read ech line of the opinion
				for k in range(len(list_of_opi_words[i])):#read each word of the opinion list
				    if k!=0 and k!=1:  
					if list_of_opi_words[i][k]==ps.stem(w1[0]) and match_found!=list_of_opi_words[i][k]:
					    num_dep=num_dep+1
					    match_found=list_of_opi_words[i][k]
					    #print 'match for dep'
					if list_of_opi_words[i][k]==ps.stem(w2[0]) and match_found!=list_of_opi_words[i][k]:
					    num_dep=num_dep+1
					    match_found=list_of_opi_words[i][k]
					    #print 'match for dep'
		    
		    
		    
		
		list_new=list(count_total.iterkeys())
		
		for i in range(len(list_new)):
			if list_new[i]=='acomp':
			    num_acomp=count_total[list_new[i]]
			if list_new[i]=='ccomp':
			    num_ccomp=count_total[list_new[i]]
			if list_new[i]=='advmod':
			    num_advmod=count_total[list_new[i]]
			if list_new[i]=='advcl':
			    num_advcl=count_total[list_new[i]]
			if list_new[i]=='amod':
			    num_amod=count_total[list_new[i]]
			if list_new[i]=='xcomp':
			    num_xcomp=count_total[list_new[i]]
			if list_new[i]=='nummod' or list_new[i]=='num':
			    num_nummod=1#count_total[list_new[i]]
		  	

			if list_new[i]=='agent':
			    num_agent=count_total[list_new[i]]
			if list_new[i]=='appos':
			    num_appos=count_total[list_new[i]]
			if list_new[i]=='aux':
			    num_aux=count_total[list_new[i]]
			if list_new[i]=='auxpass':
			    num_auxpass=count_total[list_new[i]]
			if list_new[i]=='cc':
			    num_cc=count_total[list_new[i]]
			if list_new[i]=='ccomp':
			    num_ccomp=count_total[list_new[i]]
			if list_new[i]=='conj':
			    num_conj=count_total[list_new[i]]
			if list_new[i]=='cop':
			    num_cop=count_total[list_new[i]]
			if list_new[i]=='csubj':
			    num_csubj=count_total[list_new[i]]
			if list_new[i]=='csubjpass':
			    num_csubjpass=count_total[list_new[i]]
			if list_new[i]=='dep':
			    num_dep=count_total[list_new[i]]
			if list_new[i]=='det':
			    num_det=count_total[list_new[i]]
			if list_new[i]=='discourse':
			    num_discourse=count_total[list_new[i]]
			if list_new[i]=='dobj':
			    num_dobj=count_total[list_new[i]]
			if list_new[i]=='expl':
			    num_expl=count_total[list_new[i]]
			if list_new[i]=='goes with':
			    num_goes_with=count_total[list_new[i]]
			if list_new[i]=='iobj':
			    num_iobj=count_total[list_new[i]]
			if list_new[i]=='mark':
			    num_mark=count_total[list_new[i]]
			if list_new[i]=='mwe':
			    num_mwe=count_total[list_new[i]]
			if list_new[i]=='neg':
			    num_neg=count_total[list_new[i]]	
			if list_new[i]=='nn':
			    num_nn=count_total[list_new[i]]
			if list_new[i]=='npadvmod':
			    num_npadvmod=count_total[list_new[i]]
			if list_new[i]=='nsubj':
			    num_nsubj=count_total[list_new[i]]
			if list_new[i]=='nsubjpass':
			    num_nsubjpass=count_total[list_new[i]]
			if list_new[i]=='num':
			    num_num=count_total[list_new[i]]
			if list_new[i]=='number':
			    num_number=count_total[list_new[i]]
			if list_new[i]=='parataxis':
			    num_parataxis=count_total[list_new[i]]
			if list_new[i]=='pcomp':
			    num_pcomp=count_total[list_new[i]]
			if list_new[i]=='pobj':
			    num_pobj=count_total[list_new[i]]
			if list_new[i]=='poss':
			    num_poss=count_total[list_new[i]]
			if list_new[i]=='possessive':
			    num_possessive=count_total[list_new[i]]
			if list_new[i]=='preconj':
			    num_preconj=count_total[list_new[i]]
			if list_new[i]=='predet':
			    num_predet=count_total[list_new[i]]
			if list_new[i]=='prep':
			    num_prep=count_total[list_new[i]]
			if list_new[i]=='prepc':
			    num_prepc=count_total[list_new[i]]	
			if list_new[i]=='prt':
			    num_prt=count_total[list_new[i]]
			if list_new[i]=='punct':
			    num_punct=count_total[list_new[i]]
			if list_new[i]=='quantmod':
			    num_quantmod=count_total[list_new[i]]
			if list_new[i]=='rcmod':
			    num_rcmod=count_total[list_new[i]]
			if list_new[i]=='ref':
			    num_ref=count_total[list_new[i]]
			if list_new[i]=='root':
			    num_root=count_total[list_new[i]]
			if list_new[i]=='tmod':
			    num_tmod=count_total[list_new[i]]
			if list_new[i]=='vmod':
			    num_vmod=count_total[list_new[i]]
			if list_new[i]=='xcomp':
			    num_xcomp=count_total[list_new[i]]
			if list_new[i]=='xsubj':
			    num_xsubj=count_total[list_new[i]]
		

		num_of_acomp.append(num_acomp)
		num_of_ccomp.append(num_ccomp)
		num_of_amod.append(num_amod)
		num_of_advcl.append(num_advcl)
		num_of_advmod.append(num_advmod)
		num_of_xcomp.append(num_xcomp)
		num_of_nummod.append(num_nummod)
		num_of_dep.append(num_dep)
		num_of_dobj.append(num_dobj)
		num_of_iobj.append(num_iobj)
	
		num_of_agent.append(num_agent)
		num_of_appos.append(num_appos)
		num_of_aux.append(num_aux)
		num_of_auxpass.append(num_auxpass)
		num_of_cc.append(num_cc)
		#num_of_ccomp.append(num_ccomp)
		num_of_conj.append(num_conj)
		num_of_cop.append(num_cop)
		num_of_csubj.append(num_csubj)
		num_of_csubjpass.append(num_csubjpass)
		num_of_det.append(num_det)
		num_of_discourse.append(num_discourse)
		num_of_expl.append(num_expl)
		num_of_goes_with.append(num_goes_with)
		num_of_mark.append(num_mark)
		num_of_mwe.append(num_mwe)
		num_of_neg.append(num_neg)
		num_of_nn.append(num_nn)
		num_of_npadvmod.append(num_npadvmod)
		num_of_nsubj.append(num_nsubj)
		num_of_nsubjpass.append(num_nsubjpass)
		num_of_num.append(num_num)
		num_of_number.append(num_number)
		num_of_parataxis.append(num_parataxis)
		num_of_pcomp.append(num_pcomp)
		num_of_pobj.append(num_pobj)
		num_of_poss.append(num_poss)
		num_of_possessive.append(num_possessive)
		num_of_preconj.append(num_preconj)
		num_of_predet.append(num_predet)
		num_of_prep.append(num_prep)
		num_of_prepc.append(num_prepc)
		num_of_prt.append(num_prt)
		num_of_punct.append(num_punct)
		num_of_quantmod.append(num_quantmod)
		num_of_rcmod.append(num_rcmod)
		num_of_ref.append(num_ref)
		num_of_root.append(num_root)
		num_of_tmod.append(num_tmod)
		num_of_vmod.append(num_vmod)
		num_of_xcomp.append(num_xcomp)
		num_of_xsubj.append(num_xsubj)




	print "8"
	for i in range(len(vCol)):
		
		f_output.write("\""+str(original_hashtags[i])+"\""+","+str(vCol[i])+","+str(aCol[i])+","+str(no_of_strong_adj[i])+","+str(no_of_weak_adj[i])+","+str(no_of_pronoun[i])+","+str(num_of_adverbs[i])+","+str(num_of_acomp[i])+","+str(num_of_advcl[i])+","+str(num_of_amod[i])+","+str(num_of_ccomp[i])+","+str(num_of_xcomp[i])+","+str(num_of_nummod[i])+","+str(num_of_dep[i])+","+str(num_of_dobj[i])+","+str(num_of_iobj[i])+","+str(report_words[i])+","+str(judgement_words[i])+","+str(advise_words[i])+","+str(sentiment_words[i])+","+str(no_of_nouns[i])+","+str(named_entity_present[i])+","+str(num_of_agent[i])+","+str(num_of_appos[i])+","+str(num_of_aux[i])+","+str(num_of_auxpass[i])+","+str(num_of_cc[i])+","+str(num_of_conj[i])+","+str(num_of_cop[i])+","+str(num_of_csubj[i])+","+str(num_of_csubjpass[i])+","+str(num_of_det[i])+","+str(num_of_discourse[i])+","+str(num_of_expl[i])+","+str(num_of_goes_with[i])+","+str(num_of_mark[i])+","+str(num_of_mwe[i])+","+str(num_of_neg[i])+","+str(num_of_nn[i])+","+str(num_of_npadvmod[i])+","+str(num_of_nsubj[i])+","+str(num_of_nsubjpass[i])+","+str(num_of_num[i])+","+str(num_of_number[i])+","+str(num_of_parataxis[i])+","+str(num_of_pcomp[i])+","+str(num_of_pobj[i])+","+str(num_of_poss[i])+","+str(num_of_possessive[i])+","+str(num_of_preconj[i])+","+str(num_of_predet[i])+","+str(num_of_prep[i])+","+str(num_of_prepc[i])+","+str(num_of_prt[i])+","+str(num_of_punct[i])+","+str(num_of_quantmod[i])+","+str(num_of_rcmod[i])+","+str(num_of_ref[i])+","+str(num_of_root[i])+","+str(num_of_tmod[i])+","+str(num_of_vmod[i])+","+str(num_of_xcomp[i])+","+str(num_of_xsubj[i])+","+fo[i]+"\n")																									
																																																																																		
































elif(k==2):

	# for hashtags

	filename="opinion_subclasses_1 - Sheet1.csv"
	f=open("hashtags"+"/opinion_subclasses_1 - Sheet1.csv",'r')
	f_lines=csv.reader(f) 
	
	f_output=open("result/hashtag_sub_opinion_result.csv","w")	
	
	wh_words = ['what', 'who', 'why', 'when', 'how', 'where']
	opinion_indicators = ['like', 'want', 'vote','thing','experience','moment']
	fact_words = ['quiz','contest','awards','summit','conference','hour','game','club','show','song','trip','league','tour']
	
	
	
	hashtags=[]
	hashtags_segmented=[]


	file_of_strong_adj=open("strong.txt")
	list_of_strong_adj_words=file_of_strong_adj.readlines()
	for i in range(len(list_of_strong_adj_words)):
		list_of_strong_adj_words[i]=list_of_strong_adj_words[i].strip("\r\n")
	
	file_of_weak_adj=open("weak.txt")
	list_of_weak_adj_words=file_of_weak_adj.readlines()
	for i in range(len(list_of_weak_adj_words)):
		list_of_weak_adj_words[i]=list_of_weak_adj_words[i].strip("\r\n")



	file_of_stop_words=open("stop_words.txt")
	list_of_stop_words=file_of_stop_words.readlines()
	for i in range(len(list_of_stop_words)):
		list_of_stop_words[i]=list_of_stop_words[i].strip("\r\n")

	#print list_of_stop_words
	file_of_opi_words=open("opi_words.txt")
	list_of_opi_lines=file_of_opi_words.readlines()

	for i in range(len(list_of_opi_lines)):
		list_of_opi_lines[i]=list_of_opi_lines[i].strip("\r\n")
	#print list_of_opi_lines
	
	list_of_opi_words=[]
	for line in list_of_opi_lines:
		l=line.split()
		list_of_opi_words.append(l) 
		
		
	original_hashtags=[]
	no_of_words=[]
	char_count=[]
	fo=[]
	for hashtag in f_lines:
		original_hashtags.append(hashtag[0])
		f_o=hashtag[2]
		fo.append(f_o)
		#print original_hashtags 
		hash_string=""
	    	#re.sub('^[0-9 ]*','',hashtag)
	    	char_count.append(len(hashtag[0]))
	    	hashtag=segment(hashtag[0])
		#print hashtag 
	    	hashtags_segmented.append(hashtag)
	    	no_of_words.append(len(hashtag))
	    	for s in hashtag:
	    		hash_string += s+" "
	    	hashtags.append(hash_string)
		#print hash_string
	    	#print hashtags
	#print hashtags 
	postagged_hashtags=CMUTweetTagger.runtagger_parse(hashtags)
	#print postagged_hashtags


	#newline = [str.split(',')[0] for str in lines]
	vCol = []
	aCol = []
	sVCol = []
	whCol = []
	opCol = []
	rep =[]
	mentions = []
	fact_col = []
	no_of_strong_adj=[]
	no_of_weak_adj=[]
	num_words=[]
	num_of_adverbs=[]
	no_of_pronoun = []
	num_of_acomp=[]
	num_of_ccomp=[]
	num_of_amod=[]
	num_of_advcl=[]
	num_of_advmod=[]
	num_of_xcomp=[]
	num_of_nummod=[]
	num_of_dep=[]
	num_of_dobj=[]
	num_of_iobj=[]

	num_of_aux=[]
	num_of_det=[]
	num_of_nsubj=[]
	num_of_mark=[]
	num_of_conj=[]
	num_of_cop=[]
	num_of_cc=[]
	num_of_parataxis=[]
	num_of_neg=[]
	num_of_auxpass=[]
	num_of_nsubjpass=[]
	num_of_expl=[]
	num_of_csubj=[]

	report_words=[]
	judgement_words=[]
	advise_words=[]
	sentiment_words=[]
	named_entity_present=[]
	no_of_nouns=[]
	#presence_of_year=[] 
	#end_with_day =[]
	#start_with_the = []

	hashtags_segmented_without_stop_words=[]
	for tag in hashtags_segmented:
		count_of_strong_adj=0
		count_of_weak_adj=0
		num_words.append(len(tag))
		for word in tag:
			if word in list_of_strong_adj_words:
				count_of_strong_adj += 1
	
			if word in list_of_weak_adj_words:
				count_of_weak_adj += 1
	
			if word not in list_of_stop_words:
				hashtags_segmented_without_stop_words.append(word)
		
		no_of_strong_adj.append(count_of_strong_adj)		
		no_of_weak_adj.append(count_of_weak_adj)

	ps=PorterStemmer()

	hashtags_stemmed=[]
	for line in postagged_hashtags:
		pronoun_num=noun_num=num_adverbs=rep_or_add_with=mention=0
		v=a=sv=ne=y=0
		svt=evd=0
		stemmed = []
		for tuple_t in line:
			sentence = tuple_t[1]
			if 'V' == sentence:
				v+=1
		
			if 'A' == sentence:
				a+=1
		
			if 'V' == line[0][1]:
				sv=1
			
			if sentence in ['Z', '^', 'M']:
				ne+=1
				noun_num += 1
				
			if 'O' == sentence:
				pronoun_num +=1
		
			if sentence in ['N', 'S', 'L']:
				noun_num += 1
			
			if 'N' == sentence or 'O' == sentence:
				stemmed.append(tuple_t[0])
			else:
				stemmed.append(ps.stem(tuple_t[0]))
			if sentence in ['R']:
				num_adverbs+=1
			
			if line[0][0] in ["replace","add"]:
				for i in range(len(line)):
					if line[i][0] == "with":
						rep_or_add_with=1
		
			if line[0][0] in ["mention","tweet","name","vote","reasons"]:
				mention=1
		
		
	

			
			
		vCol.append(v)
		aCol.append(a)
		rep.append(rep_or_add_with)
		mentions.append(mention)
		sVCol.append(sv)
		named_entity_present.append(ne)
		no_of_pronoun.append(pronoun_num)
		no_of_nouns.append(noun_num)
		hashtags_stemmed.append(stemmed)	
		num_of_adverbs.append(num_adverbs)
	
	for line in hashtags_stemmed:
		match_list=[]
		
		num_report=num_advise=num_judgement=num_sentiment=0
		for word in line:
			for lis in list_of_opi_words:
				if word in lis:
					match_list.append(lis[0])
					
		for num_out in match_list:
			if num_out=='1':
		            num_report=1
		        if num_out=='2':
		            num_judgement=1
		        if num_out=='3':
		            num_advise=1
		        if num_out=='4':
		            num_sentiment=1
		#opCol.append(op)
		report_words.append(num_report)
		judgement_words.append(num_judgement)
		advise_words.append(num_advise)
		sentiment_words.append(num_sentiment)
	
	
				
	#print sVCol
	for line in postagged_hashtags:
		wh = 0
		fc = 0
		op = 0
		#se = False
		for tuple_t in line:
			word = tuple_t[0]
			if word in wh_words:
				wh = 1
			if word in opinion_indicators:
				op = 1
			if word in fact_words:
				fc = 1
		
		
		whCol.append(wh)
	
		opCol.append(op)
	
		fact_col.append(fc)
	
	


	dep_parser=StanfordDependencyParser('stanford-parser/stanford-parser.jar','stanford-parser/stanford-parser-3.6.0-models.jar')

	for line in hashtags :

		result=dep_parser.raw_parse(line)
		dep=result.next()
		k_tri=list(dep.triples())
		#print k_tri
		count_total=Counter(tags for word1,tags,word2 in k_tri)
		num_acomp=num_ccomp=num_amod=num_advcl=num_advmod=num_xcomp=num_nummod=num_dep=num_dobj=num_iobj=num_aux=num_det=num_nsubj=num_mark=num_conj=num_cop=0
		num_cc=num_parataxis=num_neg=num_auxpass=num_nsubjpass=num_expl=num_csubj=0		


		match_found=None               
		for w1,tag,w2 in k_tri:
			if tag=='dobj':
		    		num_dobj=1
		    		#print w1[0]
		    		if w1[1] == 'V':
		    			for i in range(len(list_of_opi_words)):
		    				for k in range(len(list_of_opi_words[i])):
		    					if k!=0 and k!=1:
		    						if list_of_opi_words[i][k]==ps.stem(w1[0]) and match_found!=list_of_opi_words[i][k]:
		    							num_dobj=num_dobj+1
		                                			match_found=list_of_opi_words[i][k]
		                                			#print 'match for dobj'
		
				   
			if tag=='iobj':
			    #print w1[0]
			    num_iobj=1
			    if w1[1] == 'V':
				for i in range(len(list_of_opi_words)):
		    				for k in range(len(list_of_opi_words[i])):
		    					if k!=0 and k!=1:
		    						if list_of_opi_words[i][k]==ps.stem(w1[0]) and match_found!=list_of_opi_words[i][k]:
		    							num_iobj=num_iobj+1
		                                			match_found=list_of_opi_words[i][k]
		                                			#print 'match for iobj' 
					    
				        
			if tag=='dep':
			    num_dep=num_dep+1
			    #print w1[0]
			    #print w2[0]
			    for i in range(len(list_of_opi_words)):#read ech line of the opinion
				for k in range(len(list_of_opi_words[i])):#read each word of the opinion list
				    if k!=0 and k!=1:  
					if list_of_opi_words[i][k]==ps.stem(w1[0]) and match_found!=list_of_opi_words[i][k]:
					    num_dep=num_dep+1
					    match_found=list_of_opi_words[i][k]
					    #print 'match for dep'
					if list_of_opi_words[i][k]==ps.stem(w2[0]) and match_found!=list_of_opi_words[i][k]:
					    num_dep=num_dep+1
					    match_found=list_of_opi_words[i][k]
					    #print 'match for dep'
		    
		    
		    
		
		list_new=list(count_total.iterkeys())
		
		
		for i in range(len(list_new)):#opinion
			if list_new[i]=='acomp':
			    num_acomp=count_total[list_new[i]]
			if list_new[i]=='ccomp':
			    num_ccomp=count_total[list_new[i]]
			if list_new[i]=='advmod':
			    num_advmod=count_total[list_new[i]]
			if list_new[i]=='advcl':
			    num_advcl=count_total[list_new[i]]
			if list_new[i]=='amod':
			    num_amod=count_total[list_new[i]]
			if list_new[i]=='xcomp':
			    num_xcomp=count_total[list_new[i]]
			#if list_new[i]=='nummod' or list_new[i]=='num':
			#    num_nummod=1#count_total[list_new[i]]
	
		  	
			if list_new[i]=='aux':
			    num_aux=count_total[list_new[i]]
			if list_new[i]=='auxpass':
			    num_auxpass=count_total[list_new[i]]
			if list_new[i]=='cc':
			    num_cc=count_total[list_new[i]]
			if list_new[i]=='ccomp':
			    num_ccomp=count_total[list_new[i]]
			if list_new[i]=='conj':
			    num_conj=count_total[list_new[i]]
			if list_new[i]=='cop':
			    num_cop=count_total[list_new[i]]
			if list_new[i]=='csubj':
			    num_csubj=count_total[list_new[i]]
			if list_new[i]=='dep':
			    num_dep=count_total[list_new[i]]
			if list_new[i]=='det':
			    num_det=count_total[list_new[i]]
		
			if list_new[i]=='dobj':
			    num_dobj=count_total[list_new[i]]
			if list_new[i]=='expl':
			    num_expl=count_total[list_new[i]]
		
			if list_new[i]=='iobj':
			    num_iobj=count_total[list_new[i]]
			if list_new[i]=='mark':
			    num_mark=count_total[list_new[i]]
		
			if list_new[i]=='neg':
			    num_neg=count_total[list_new[i]]	
		
			if list_new[i]=='nsubj':
			    num_nsubj=count_total[list_new[i]]
			if list_new[i]=='nsubjpass':
			    num_nsubjpass=count_total[list_new[i]]
		
			if list_new[i]=='parataxis':
			    num_parataxis=count_total[list_new[i]]
		
			if list_new[i]=='xcomp':
			    num_xcomp=count_total[list_new[i]]
		  	
		  	
		  	
	  	
		  	
		  	
		  	
		  	
		num_of_aux.append(num_aux)
		num_of_det.append(num_det)
		num_of_nsubj.append(num_nsubj)
		num_of_mark.append(num_mark)
		num_of_conj.append(num_conj)
		num_of_cop.append(num_cop)
		num_of_cc.append(num_cc)
		num_of_parataxis.append(num_parataxis)
		num_of_neg.append(num_neg)
		num_of_auxpass.append(num_auxpass)
		num_of_nsubjpass.append(num_nsubjpass)
		num_of_expl.append(num_expl)
		num_of_csubj.append(num_csubj) 	
		  	
		  	
		num_of_acomp.append(num_acomp)
		num_of_ccomp.append(num_ccomp)
		num_of_amod.append(num_amod)
		num_of_advcl.append(num_advcl)
		num_of_advmod.append(num_advmod)
		num_of_xcomp.append(num_xcomp)
		num_of_nummod.append(num_nummod)
		num_of_dep.append(num_dep)
		num_of_dobj.append(num_dobj)
		num_of_iobj.append(num_iobj)
	

	
	f_output.write("hashtag,no_of_verbs,adj present,verb at start,wh words,opinion_words,fact_words,strong_adjective,weak_adjective,num_words,no_of_pronoun,acomp,advcl,amod,ccomp,xcomp,num_nummod,dep,dobj,iobj,report_words,judgement_words,advise_words,sentiment_words,char_count,no_of_nouns,named_entity_present,opinion_words,fact_words,aux,det,nsubj,mark,conj,cop,cc,parataxis,neg,auxpass,nsubjpass,expl,csubj,no_of_adverbs,rep,mentions,sentiment,\n")
	
	for i in range(len(vCol)):
	
		
		f_output.write("\""+original_hashtags[i]+"\""+","+str(vCol[i])+","+str(aCol[i])+","+str(sVCol[i])+","+str(whCol[i])+","+str(opCol[i])+","+str(fact_col[i])+","+str(no_of_strong_adj[i])+","+str(no_of_weak_adj[i])+","+str(num_words[i])+","+str(no_of_pronoun[i])+","+str(num_of_acomp[i])+","+str(num_of_advcl[i])+","+str(num_of_amod[i])+","+str(num_of_ccomp[i])+","+str(num_of_xcomp[i])+","+str(num_of_nummod[i])+","+str(num_of_dep[i])+","+str(num_of_dobj[i])+","+str(num_of_iobj[i])+","+str(report_words[i])+","+str(judgement_words[i])+","+str(advise_words[i])+","+str(sentiment_words[i])+","+str(char_count[i])+","+str(no_of_nouns[i])+","+str(named_entity_present[i])+","+str(opCol[i])+","+str(fact_col[i])+","+str(num_of_aux[i])+","+str(num_of_det[i])+","+str(num_of_nsubj[i])+","+str(num_of_mark[i])+","+str(num_of_conj[i])+","+str(num_of_cop[i])+","+str(num_of_cc[i])+","+str(num_of_parataxis[i])+","+str(num_of_neg[i])+","+str(num_of_auxpass[i])+","+str(num_of_nsubjpass[i])+","+str(num_of_expl[i])+","+str(num_of_csubj[i])+","+str(num_of_adverbs[i])+","+str(rep[i])+","+str(mentions[i])+","+str(fo[i])+"\n")
	
		






































elif(k==3):
	#newspaper
	
	
	folder_name="./newspaper_131_articles"
	f_output=open("./result/newspaper_sub_opinion_result.csv","w")		
	f_output.write("hashtag,verb present,adj present,strong_adjective,weak_adjective,no_of_pronouns,no_of_adverbs,acomp,advcl,amod,ccomp,xcomp,nummod,dep,dobj,iobj,report_words,judgement_words,advise_words,sentiment_words,no_of_nouns,named_entity_present,num_of_agent,num_of_appos,num_of_aux,num_of_auxpass,num_of_cc,num_of_conj,num_of_cop,num_of_csubj,num_of_csubjpass,num_of_det,num_of_discourse,num_of_expl,num_of_goes_with,num_of_mark,num_of_mwe,num_of_neg,num_of_nn,num_of_npadvmod,num_of_nsubj,num_of_nsubjpass,num_of_num,num_of_number,num_of_parataxis,num_of_pcomp,num_of_pobj,num_of_poss,num_of_possessive,num_of_preconj,num_of_predet,num_of_prep,num_of_prepc,num_of_prt,num_of_punct,num_of_quantmod,num_of_rcmod,num_of_ref,num_of_root,num_of_tmod,num_of_vmod,num_of_xcomp,num_of_xsubj,fo\n")
	
	file_of_strong_adj=open("strong.txt")
	list_of_strong_adj_words=file_of_strong_adj.readlines()
	for i in range(len(list_of_strong_adj_words)):
		list_of_strong_adj_words[i]=list_of_strong_adj_words[i].strip("\r\n")
	
	file_of_weak_adj=open("weak.txt")
	list_of_weak_adj_words=file_of_weak_adj.readlines()
	for i in range(len(list_of_weak_adj_words)):
		list_of_weak_adj_words[i]=list_of_weak_adj_words[i].strip("\r\n")

	file_of_stop_words=open("stop_words.txt")
	list_of_stop_words=file_of_stop_words.readlines()
	for i in range(len(list_of_stop_words)):
		list_of_stop_words[i]=list_of_stop_words[i].strip("\r\n")

	
	file_of_opi_words=open("opi_words.txt")
	list_of_opi_lines=file_of_opi_words.readlines()
	for i in range(len(list_of_opi_lines)):
		list_of_opi_lines[i]=list_of_opi_lines[i].strip("\r\n")
	

	list_of_opi_words=[]
	for line in list_of_opi_lines:
		l=line.split()
		list_of_opi_words.append(l) 
	
	import os
	for filename in os.listdir(folder_name):
	
		print filename
		hashtags=[]
		hashtags_segmented=[]
		original_hashtags=[]
		no_of_words=[]
		
		f=open(folder_name+"/"+filename,'r')
		f_lines=csv.reader(f) 
		fo=[]
		char_count=[]
		f.readline()
		
		for hashtag in f_lines:
			
			f_o=hashtag[2]
			hashtag=hashtag[0]
	
			
			original_hashtags.append(hashtag)
			
	
		    	re.sub('^[0-9 ]*','',hashtag)
		    	

		    	hashtags_segmented.append(hashtag.split())
		    	
		  	hash_string = hashtag
		    	hashtags.append(hash_string)
			fo.append(f_o)
	
		
		postagged_hashtags=[] 
		print "1"
		st=StanfordPOSTagger('./stanford-postagger/models/english-bidirectional-distsim.tagger','./stanford-postagger/stanford-postagger.jar')
		    
		for line in hashtags:
			postagged_hashtags.append(st.tag([line]))
		
		print "2"

		#newline = [str.split(',')[0] for str in lines]
		vCol = []
		aCol = []
		sVCol = []
		whCol = []
		opCol = []
		fact_col = []
		no_of_strong_adj=[]
		no_of_weak_adj=[]
		num_words=[]
		no_of_pronoun = []
		num_of_adverbs=[]

		num_of_acomp=[]
		num_of_ccomp=[]
		num_of_amod=[]
		num_of_advcl=[]
		num_of_advmod=[]
		num_of_xcomp=[]
		num_of_nummod=[]
		num_of_dep=[]
		num_of_dobj=[]
		num_of_iobj=[]
		num_of_agent=[]
		num_of_cop=[]
		num_of_appos=[]
		num_of_aux=[]
		num_of_auxpass=[]
		num_of_cc=[]
		num_of_ccomp=[]
		num_of_conj=[]
		num_of_csubj=[]
		num_of_csubjpass=[]
		num_of_dep=[]
		num_of_det=[]
		num_of_discourse=[]
		num_of_expl=[]
		num_of_goes_with=[]
		num_of_mark=[]
		num_of_mwe=[]
		num_of_neg=[]
		num_of_nn=[]
		num_of_npadvmod=[]
		num_of_nsubj=[]
		num_of_nsubjpass=[]
		num_of_number=[]
		num_of_num=[]
		num_of_parataxis=[]
		num_of_pcomp=[]
		num_of_pobj=[]
		num_of_poss=[]
		num_of_possessive=[]
		num_of_preconj=[]
		num_of_preconj=[]
		num_of_predet=[]
		num_of_prep=[]
		num_of_prepc=[]
		num_of_prt=[]
		num_of_punct=[]
		num_of_quantmod=[]
		num_of_rcmod=[]
		num_of_ref=[]
		num_of_root=[]
		num_of_tmod=[]
		num_of_vmod=[]
		num_of_xcomp=[]
		num_of_xsubj=[]


		report_words=[]
		judgement_words=[]
		advise_words=[]
		sentiment_words=[]
		named_entity_present=[]
		no_of_nouns=[]
		presence_of_year=[] 
		end_with_day =[]
		start_with_the = []
		report_words=[]
		judgement_words=[]
		advise_words=[]
		sentiment_words=[]
		named_entity_present=[]
		no_of_nouns=[]
		presence_of_year=[] 
		end_with_day =[]
		start_with_the = []
		#print hashtags_segmented
		print "3"
		hashtags_segmented_without_stop_words=[]
		for tag in hashtags_segmented:
			count_of_strong_adj=0
			count_of_weak_adj=0
			num_words.append(len(tag))
			for word in tag:
				if word in list_of_strong_adj_words:
					count_of_strong_adj += 1

				if word in list_of_weak_adj_words:
					count_of_weak_adj += 1

				if word not in list_of_stop_words:
					hashtags_segmented_without_stop_words.append(word)
	
			no_of_strong_adj.append(count_of_strong_adj)		
			no_of_weak_adj.append(count_of_weak_adj)
		print "4"
		ps=PorterStemmer()

		hashtags_stemmed=[]
		for line in postagged_hashtags:
			pronoun_num=noun_num=0
			v=a=sv=ne=y=0
			svt=evd=0
			num_adverbs=0
			stemmed = []
			for tuple_t in line:
				sentence = tuple_t[1]
				if sentence in ['VB','VBN','VBD','VBG','VBP','VBZ'] :
					v += 1
	
				if  sentence in ['JJ','JJR','JJS']:
					a += 1
				if sentence in ['RB','RBR','RBS','WRB']	:
					num_adverbs += 1
				#if 'V' == line[0][1]:
				#	sv=1
		
				if sentence in ['NN','NNS','NNP','NNPS']:
					noun_num += 1
			
				if sentence in ['PRP','PRP$']:
					pronoun_num +=1

				if sentence in ['NNP','NNPS']:
					ne += 1
				#if sentence in ['N', 'S', 'L']:
				#	noun_num += 1
		
				if sentence in ['NN','NNS','NNP','NNPS','PR','PRP$','WP','WP$']:
					stemmed.append(tuple_t[0])
				else:
					stemmed.append(ps.stem(tuple_t[0]))
	
				#if '$' == sentence:
				#	if sentence.isdigit():
				#		y=1

				#if line[0][0] == 'the':
				#	svt=1
	
				#if line[len(line)-1][0] == 'day':
				#	evd=1

		
		
			vCol.append(v)
			aCol.append(a)
			num_of_adverbs.append(num_adverbs)
			named_entity_present.append(ne)
			no_of_pronoun.append(pronoun_num)
			no_of_nouns.append(noun_num)
			hashtags_stemmed.append(stemmed)
					


		print "5"
		for line in hashtags_stemmed:
			match_list=[]
			#op = 0
			num_report=num_advise=num_judgement=num_sentiment=0
			for word in line:
				for lis in list_of_opi_words:
					if word in lis:
						match_list.append(lis[0])
						#op = 1
			for num_out in match_list:
				if num_out=='1':
				    num_report=1
				if num_out=='2':
				    num_judgement=1
				if num_out=='3':
				    num_advise=1
				if num_out=='4':
				    num_sentiment=1
			
			report_words.append(num_report)
			judgement_words.append(num_judgement)
			advise_words.append(num_advise)
			sentiment_words.append(num_sentiment)
	
		


		dep_parser=StanfordDependencyParser('stanford-parser/stanford-parser.jar','stanford-parser/stanford-parser-3.6.0-models.jar')
		print "7"
		for line in hashtags :
			print line
			result=dep_parser.raw_parse(line)
			dep=result.next()
			k_tri=list(dep.triples())
			#print k_tri
			count_total=Counter(tags for word1,tags,word2 in k_tri)
			num_acomp=num_ccomp=num_amod=num_advcl=num_advmod=num_xcomp=num_nummod=num_dep=num_dobj=num_iobj=num_agent=num_appos=num_aux=num_auxpass=num_cc=num_ccomp=num_conj=num_cop=num_csubj=num_csubjpass=num_dep=num_det=num_discourse=num_dobj=num_expl=num_goes_with=num_iobj=num_mark=num_mwe=num_neg=num_nn=num_npadvmod=num_nsubj=num_nsubjpass=num_num=num_number=num_parataxis=num_pcomp=num_pobj=num_poss=num_possessive=num_preconj=num_predat=num_predet=num_prep=num_prepc=num_prt=num_punct=num_quantmod=num_rcmod=num_ref=num_root=num_tmod=num_vmod=num_xcomp=num_xsubj=0
	
			
			match_found=None               
			for w1,tag,w2 in k_tri:
				if tag=='dobj':
			    		num_dobj=1
			    		#print w1[0]
			    		if w1[1] in ['VB','VBN','VBD','VBG','VBP','VBZ'] :
			    			for i in range(len(list_of_opi_words)):
			    				for k in range(len(list_of_opi_words[i])):
			    					if k!=0 and k!=1:
			    						if list_of_opi_words[i][k]==ps.stem(w1[0]) and match_found!=list_of_opi_words[i][k]:
			    							num_dobj=num_dobj+1
					                			match_found=list_of_opi_words[i][k]
					                			#print 'match for dobj'
	
					   
				if tag=='iobj':
				    #print w1[0]
				    num_iobj=1
				    if w1[1]in ['VB','VBN','VBD','VBG','VBP','VBZ'] :
					for i in range(len(list_of_opi_words)):
			    				for k in range(len(list_of_opi_words[i])):
			    					if k!=0 and k!=1:
			    						if list_of_opi_words[i][k]==ps.stem(w1[0]) and match_found!=list_of_opi_words[i][k]:
			    							num_iobj=num_iobj+1
					                			match_found=list_of_opi_words[i][k]
					                			#print 'match for iobj' 
						    
					
				if tag=='dep':
				    num_dep=num_dep+1
				    #print w1[0]
				    #print w2[0]
				    for i in range(len(list_of_opi_words)):#read ech line of the opinion
					for k in range(len(list_of_opi_words[i])):#read each word of the opinion list
					    if k!=0 and k!=1:  
						if list_of_opi_words[i][k]==ps.stem(w1[0]) and match_found!=list_of_opi_words[i][k]:
						    num_dep=num_dep+1
						    match_found=list_of_opi_words[i][k]
						    #print 'match for dep'
						if list_of_opi_words[i][k]==ps.stem(w2[0]) and match_found!=list_of_opi_words[i][k]:
						    num_dep=num_dep+1
						    match_found=list_of_opi_words[i][k]
						    #print 'match for dep'
			    
			    
			    
			
			list_new=list(count_total.iterkeys())
			
			for i in range(len(list_new)):
				if list_new[i]=='acomp':
				    num_acomp=count_total[list_new[i]]
				if list_new[i]=='ccomp':
				    num_ccomp=count_total[list_new[i]]
				if list_new[i]=='advmod':
				    num_advmod=count_total[list_new[i]]
				if list_new[i]=='advcl':
				    num_advcl=count_total[list_new[i]]
				if list_new[i]=='amod':
				    num_amod=count_total[list_new[i]]
				if list_new[i]=='xcomp':
				    num_xcomp=count_total[list_new[i]]
				if list_new[i]=='nummod' or list_new[i]=='num':
				    num_nummod=1#count_total[list_new[i]]
			  	

				if list_new[i]=='agent':
				    num_agent=count_total[list_new[i]]
				if list_new[i]=='appos':
				    num_appos=count_total[list_new[i]]
				if list_new[i]=='aux':
				    num_aux=count_total[list_new[i]]
				if list_new[i]=='auxpass':
				    num_auxpass=count_total[list_new[i]]
				if list_new[i]=='cc':
				    num_cc=count_total[list_new[i]]
				if list_new[i]=='ccomp':
				    num_ccomp=count_total[list_new[i]]
				if list_new[i]=='conj':
				    num_conj=count_total[list_new[i]]
				if list_new[i]=='cop':
				    num_cop=count_total[list_new[i]]
				if list_new[i]=='csubj':
				    num_csubj=count_total[list_new[i]]
				if list_new[i]=='csubjpass':
				    num_csubjpass=count_total[list_new[i]]
				if list_new[i]=='dep':
				    num_dep=count_total[list_new[i]]
				if list_new[i]=='det':
				    num_det=count_total[list_new[i]]
				if list_new[i]=='discourse':
				    num_discourse=count_total[list_new[i]]
				if list_new[i]=='dobj':
				    num_dobj=count_total[list_new[i]]
				if list_new[i]=='expl':
				    num_expl=count_total[list_new[i]]
				if list_new[i]=='goes with':
				    num_goes_with=count_total[list_new[i]]
				if list_new[i]=='iobj':
				    num_iobj=count_total[list_new[i]]
				if list_new[i]=='mark':
				    num_mark=count_total[list_new[i]]
				if list_new[i]=='mwe':
				    num_mwe=count_total[list_new[i]]
				if list_new[i]=='neg':
				    num_neg=count_total[list_new[i]]	
				if list_new[i]=='nn':
				    num_nn=count_total[list_new[i]]
				if list_new[i]=='npadvmod':
				    num_npadvmod=count_total[list_new[i]]
				if list_new[i]=='nsubj':
				    num_nsubj=count_total[list_new[i]]
				if list_new[i]=='nsubjpass':
				    num_nsubjpass=count_total[list_new[i]]
				if list_new[i]=='num':
				    num_num=count_total[list_new[i]]
				if list_new[i]=='number':
				    num_number=count_total[list_new[i]]
				if list_new[i]=='parataxis':
				    num_parataxis=count_total[list_new[i]]
				if list_new[i]=='pcomp':
				    num_pcomp=count_total[list_new[i]]
				if list_new[i]=='pobj':
				    num_pobj=count_total[list_new[i]]
				if list_new[i]=='poss':
				    num_poss=count_total[list_new[i]]
				if list_new[i]=='possessive':
				    num_possessive=count_total[list_new[i]]
				if list_new[i]=='preconj':
				    num_preconj=count_total[list_new[i]]
				if list_new[i]=='predet':
				    num_predet=count_total[list_new[i]]
				if list_new[i]=='prep':
				    num_prep=count_total[list_new[i]]
				if list_new[i]=='prepc':
				    num_prepc=count_total[list_new[i]]	
				if list_new[i]=='prt':
				    num_prt=count_total[list_new[i]]
				if list_new[i]=='punct':
				    num_punct=count_total[list_new[i]]
				if list_new[i]=='quantmod':
				    num_quantmod=count_total[list_new[i]]
				if list_new[i]=='rcmod':
				    num_rcmod=count_total[list_new[i]]
				if list_new[i]=='ref':
				    num_ref=count_total[list_new[i]]
				if list_new[i]=='root':
				    num_root=count_total[list_new[i]]
				if list_new[i]=='tmod':
				    num_tmod=count_total[list_new[i]]
				if list_new[i]=='vmod':
				    num_vmod=count_total[list_new[i]]
				if list_new[i]=='xcomp':
				    num_xcomp=count_total[list_new[i]]
				if list_new[i]=='xsubj':
				    num_xsubj=count_total[list_new[i]]
		


			num_of_acomp.append(num_acomp)
			num_of_ccomp.append(num_ccomp)
			num_of_amod.append(num_amod)
			num_of_advcl.append(num_advcl)
			num_of_advmod.append(num_advmod)
			num_of_xcomp.append(num_xcomp)
			num_of_nummod.append(num_nummod)
			num_of_dep.append(num_dep)
			num_of_dobj.append(num_dobj)
			num_of_iobj.append(num_iobj)
	
			num_of_agent.append(num_agent)
			num_of_appos.append(num_appos)
			num_of_aux.append(num_aux)
			num_of_auxpass.append(num_auxpass)
			num_of_cc.append(num_cc)
			#num_of_ccomp.append(num_ccomp)
			num_of_conj.append(num_conj)
			num_of_cop.append(num_cop)
			num_of_csubj.append(num_csubj)
			num_of_csubjpass.append(num_csubjpass)
			num_of_det.append(num_det)
			num_of_discourse.append(num_discourse)
			num_of_expl.append(num_expl)
			num_of_goes_with.append(num_goes_with)
			num_of_mark.append(num_mark)
			num_of_mwe.append(num_mwe)
			num_of_neg.append(num_neg)
			num_of_nn.append(num_nn)
			num_of_npadvmod.append(num_npadvmod)
			num_of_nsubj.append(num_nsubj)
			num_of_nsubjpass.append(num_nsubjpass)
			num_of_num.append(num_num)
			num_of_number.append(num_number)
			num_of_parataxis.append(num_parataxis)
			num_of_pcomp.append(num_pcomp)
			num_of_pobj.append(num_pobj)
			num_of_poss.append(num_poss)
			num_of_possessive.append(num_possessive)
			num_of_preconj.append(num_preconj)
			num_of_predet.append(num_predet)
			num_of_prep.append(num_prep)
			num_of_prepc.append(num_prepc)
			num_of_prt.append(num_prt)
			num_of_punct.append(num_punct)
			num_of_quantmod.append(num_quantmod)
			num_of_rcmod.append(num_rcmod)
			num_of_ref.append(num_ref)
			num_of_root.append(num_root)
			num_of_tmod.append(num_tmod)
			num_of_vmod.append(num_vmod)
			num_of_xcomp.append(num_xcomp)
			num_of_xsubj.append(num_xsubj)


		print "8"
		for i in range(len(vCol)):
				
			f_output.write("\""+str(original_hashtags[i])+"\""+","+str(vCol[i])+","+str(aCol[i])+","+str(no_of_strong_adj[i])+","+str(no_of_weak_adj[i])+","+str(no_of_pronoun[i])+","+str(num_of_adverbs[i])+","+str(num_of_acomp[i])+","+str(num_of_advcl[i])+","+str(num_of_amod[i])+","+str(num_of_ccomp[i])+","+str(num_of_xcomp[i])+","+str(num_of_nummod[i])+","+str(num_of_dep[i])+","+str(num_of_dobj[i])+","+str(num_of_iobj[i])+","+str(report_words[i])+","+str(judgement_words[i])+","+str(advise_words[i])+","+str(sentiment_words[i])+","+str(no_of_nouns[i])+","+str(named_entity_present[i])+","+str(num_of_agent[i])+","+str(num_of_appos[i])+","+str(num_of_aux[i])+","+str(num_of_auxpass[i])+","+str(num_of_cc[i])+","+str(num_of_conj[i])+","+str(num_of_cop[i])+","+str(num_of_csubj[i])+","+str(num_of_csubjpass[i])+","+str(num_of_det[i])+","+str(num_of_discourse[i])+","+str(num_of_expl[i])+","+str(num_of_goes_with[i])+","+str(num_of_mark[i])+","+str(num_of_mwe[i])+","+str(num_of_neg[i])+","+str(num_of_nn[i])+","+str(num_of_npadvmod[i])+","+str(num_of_nsubj[i])+","+str(num_of_nsubjpass[i])+","+str(num_of_num[i])+","+str(num_of_number[i])+","+str(num_of_parataxis[i])+","+str(num_of_pcomp[i])+","+str(num_of_pobj[i])+","+str(num_of_poss[i])+","+str(num_of_possessive[i])+","+str(num_of_preconj[i])+","+str(num_of_predet[i])+","+str(num_of_prep[i])+","+str(num_of_prepc[i])+","+str(num_of_prt[i])+","+str(num_of_punct[i])+","+str(num_of_quantmod[i])+","+str(num_of_rcmod[i])+","+str(num_of_ref[i])+","+str(num_of_root[i])+","+str(num_of_tmod[i])+","+str(num_of_vmod[i])+","+str(num_of_xcomp[i])+","+str(num_of_xsubj[i])+","+fo[i]+"\n")																									
																																																																																		

	
	
else:
	print "incorrect input"
	
